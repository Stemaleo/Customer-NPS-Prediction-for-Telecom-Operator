# Customer NPS Prediction for a Telecom Operator

This repository contains the solution for the Telecom NPS Prediction Take-Home Challenge. 

## Project Structure
* `src/data_preparation.py`: Ingests the raw dataset, maps Satisfaction Score to NPS Category, and drops leakage columns.
* `src/feature_engineering.py`: Contains the scikit-learn pipeline for standardizing numeric features and one-hot encoding categorical features. Handles the 15%/85% train-test split simulating the real-world survey response rate.
* `src/train_model.py`: Trains the Baseline Logistic Regression and the advanced XGBoost model using sample weights to handle class imbalance. Evaluates via Macro-F1.
* `src/evaluate_fairness.py`: Audits the recall of the Detractor class across demographic segments (`Senior Citizen`, `Gender`).
* `src/generate_plots.py`: Generates the visualizations (Confusion Matrix, NPS Distribution, SHAP Feature Importance).
* `app.py`: A Streamlit web application providing a user interface for a Retention Manager to test individual customer profiles.
* `requirements.txt`: Python package dependencies.
* `WriteUp.md`: The detailed report outlining the methodology, modeling decisions, and fairness audit.

## Setup Instructions

1. Ensure you have Python 3.9+ installed.
2. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Place the `telco_11_1_3.csv` dataset in the root directory.

## Run Instructions

To run the pipeline from end-to-end and reproduce the models:

1. **Prepare Data & Train Model:**
   ```bash
   python src/train_model.py
   ```
   *(This will automatically load the data, apply feature engineering, train the models, and output `preprocessor.joblib` and `xgb_model.joblib`)*

2. **Evaluate Fairness:**
   ```bash
   python src/evaluate_fairness.py
   ```

3. **Generate Evaluation Plots:**
   ```bash
   python src/generate_plots.py
   ```

4. **Launch the Web Application:**
   ```bash
   streamlit run app.py
   ```
   Navigate to `http://localhost:8501` in your browser to interact with the model.
